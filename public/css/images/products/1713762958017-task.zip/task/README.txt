select s.id, s.name, 
sum(CASE WHEN e.exam_name = 'prelims' THEN r.theory ELSE 0 END) as prilims_theory_total,
sum(CASE WHEN e.exam_name = 'prelims' THEN r.practical ELSE 0 END) as prilims_practical_total,
sum(CASE WHEN e.exam_name = 'terminal' THEN r.theory ELSE 0 END) as terminal_theory_total,
sum(CASE WHEN e.exam_name = 'terminal' THEN r.practical ELSE 0 END) as terminal_practical_total,
sum(CASE WHEN e.exam_name = 'final' THEN r.theory ELSE 0 END) as final_theory_total,
sum(CASE WHEN e.exam_name = 'final' THEN r.practical ELSE 0 END) as final_practical_total FROM result as r INNER JOIN student_tbl as s ON r.stu_id = s.id 
INNER JOIN exam as e ON r.exam_type = e.id group by s.id order by s.id;