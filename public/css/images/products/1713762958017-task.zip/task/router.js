const express = require("express");
const router = express.Router();
const controller = require('./controllers/controller');

router.get('/',(req,res)=>{
    res.render('pages/index.ejs');
})

router.get('/login',(req,res)=>{
    res.render('pages/login.ejs');
})

router.post('/login',controller.postLogin);

router.get('/list', controller.getdatalist);
router.get('/list1', controller.getdatalistwithPagi);
router.get('/list2', controller.getdatalistwithPagiOrderby);
router.get('/result', controller.getAllresult);
router.get('/singleresult', controller.getSingleresult);


module.exports = router;