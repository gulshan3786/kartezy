const { log } = require("console");
const con = require("../Databases/config");


exports.postLogin = (req, res) => {
    const { email, password } = req.body;
    const sql = "SELECT * FROM user  WHERE email = ? AND password = ?";
    // con.query(sql, [email, password])
}


exports.getdatalist = (req, res) => {

    const sql = "SELECT * FROM student_tbl limit 10";
    con.query(sql, (err, rows, fields) => {
        if (!err) {
            // console.log(rows.length)
            res.render("pages/list", {
                data: rows
            });
        } else {
            console.log("error in fetch data")
        }
    })

}


var numPerRecord = 15;
var totalRecords = 200;


exports.getdatalistwithPagi = (req, res) => {

    // const url = req.url;
    // const pathold = url.split("?")[0].toString();
    let pagenum = req.query.n;
    if (!req.query.n || req.query.n < 1) {
        pagenum = 1;
    }
    var n = pagenum - 1;
    let start = numPerRecord * n;
    const month = (req.query.month)? req.query.month : "1";


    let lastpage = Math.ceil(totalRecords / numPerRecord);
    
    const div = 0.3;
    const sql = `SELECT s.id,s.first_name,s.last_name,count(a.stu_id) as present_day, 
    ROUND(count(a.stu_id) / ${div},2) as percentage 
    from attandance as a 
    INNER JOIN student_tbl as s ON a.stu_id = s.id 
    where is_present = 1 and MONTH(a.date)=${month} 
    group by a.stu_id order by s.id limit ${start},${numPerRecord}`;
    con.query(sql, (err, rows) => {

        if (!err) {
            // console.log(rows.length)
            res.render("pages/list1", {
                data: rows,
                month : month,
                pagenum: pagenum,
                lastpage: lastpage
            });
        } else {
            console.log("error in fetch data")
        }
    })
}

exports.getdatalistwithPagiOrderby = (req, res) => {

    let pagenum = req.query.n;
    let order = (req.query.orderby) ? req.query.orderby : "id";
    if (!req.query.n || req.query.n < 1) {
        pagenum = 1;
    }
    var n = pagenum - 1;
    let start = numPerRecord * n;
    let lastpage = Math.ceil(totalRecords / numPerRecord);
    const sql = `SELECT * FROM student_tbl ORDER BY ${order} limit ${start},${numPerRecord}`;
    con.query(sql, (err, rows) => {
        if (!err) {
            // console.log(rows.length)
            res.render("pages/list2", {
                data: rows,
                pagenum: pagenum,
                lastpage: lastpage,
                orderby: order,
                totalRecords: totalRecords
            });
        } else {
            console.log("error in fetch data")
        }
    })
    // console.log(totalRecords);
}

exports.getAllresult = (req, res) => {

    let pagenum = req.query.n;
    if (!req.query.n || req.query.n < 1) {
        pagenum = 1;
    }
    var n = pagenum - 1;
    let start = numPerRecord * n;
    let lastpage = Math.ceil(totalRecords / numPerRecord);
    const sql = `select s.id, CONCAT(s.first_name ," ", s.last_name) as name, 
    sum(CASE WHEN e.exam_name = 'prelims' THEN r.theory ELSE 0 END) as prilims_theory_total,
    sum(CASE WHEN e.exam_name = 'prelims' THEN r.practical ELSE 0 END) as prilims_practical_total,
    sum(CASE WHEN e.exam_name = 'terminal' THEN r.theory ELSE 0 END) as terminal_theory_total,
    sum(CASE WHEN e.exam_name = 'terminal' THEN r.practical ELSE 0 END) as terminal_practical_total,
    sum(CASE WHEN e.exam_name = 'final' THEN r.theory ELSE 0 END) as final_theory_total,
    sum(CASE WHEN e.exam_name = 'final' THEN r.practical ELSE 0 END) as final_practical_total FROM result as r INNER JOIN student_tbl as s ON r.stu_id = s.id 
    INNER JOIN exam as e ON r.exam_type = e.id group by s.id order by s.id limit ${start},${numPerRecord}`;

    con.query(sql, (err, rows) => {
        if (!err) {
            res.render("pages/result", {
                data: rows,
                pagenum: pagenum,
                lastpage: lastpage
            });
        } else {
            console.log("error in fetch data")
        }
    })

}

exports.getSingleresult = (req, res) => {

    let id = req.query.id;
    const sql = `select r.stu_id,sub.id, CONCAT(s.first_name ," ", s.last_name) as stu_name, sub.name,
    max(CASE WHEN e.exam_name = 'prelims' THEN r.theory_total ELSE 0 END) as p_theory_total,
    sum(CASE WHEN e.exam_name = 'prelims' THEN r.theory ELSE 0 END) as prilims_theory_total,
    max(CASE WHEN e.exam_name = 'prelims' THEN r.practical_total ELSE 0 END) as p_practical_total,
    sum(CASE WHEN e.exam_name = 'prelims' THEN r.practical ELSE 0 END) as prilims_practical_total,
    max(CASE WHEN e.exam_name = 'terminal' THEN r.theory_total ELSE 0 END) as t_theory_total,
    sum(CASE WHEN e.exam_name = 'terminal' THEN r.theory ELSE 0 END) as terminal_theory_total,
    max(CASE WHEN e.exam_name = 'terminal' THEN r.practical_total ELSE 0 END) as t_practical_total,
    sum(CASE WHEN e.exam_name = 'terminal' THEN r.practical ELSE 0 END) as terminal_practical_total,
    max(CASE WHEN e.exam_name = 'final' THEN r.theory_total ELSE 0 END) as f_theory_total,
    sum(CASE WHEN e.exam_name = 'final' THEN r.theory ELSE 0 END) as final_theory_total,
    max(CASE WHEN e.exam_name = 'final' THEN r.practical_total ELSE 0 END) as f_practical_total,
    sum(CASE WHEN e.exam_name = 'final' THEN r.practical ELSE 0 END) as final_practical_total 
    FROM result as r INNER JOIN student_tbl as s ON r.stu_id = s.id 
    INNER JOIN exam as e ON r.exam_type = e.id INNER JOIN subject_tbl as sub ON r.sub_id = sub.id WHERE s.id = ${id} group by r.sub_id;`;

    con.query(sql, (err, rows) => {
        if (!err) {
            res.render("pages/singleresult", {
                data: rows
            });
        } else {
            console.log("error in single result fetch data")
        }
    })
    // res.send(`${id}`);
}