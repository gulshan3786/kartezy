// console.log("hello world");

// console.log(process.argv.slice(2));

// console.log(process.env);

// console.log(process.env["HOME"]);

// const args = process.argv.slice(2);
// console.log(process.env[args[0]]);

// args.forEach((arg) => {
//   console.log(process.env[arg]);
// });

// args.forEach((arg) => {
//   let avar = process.env[arg];
//   if (avar === undefined) {
//     console.error(`could not find "${arg}" in environment`);
//   } else {
//     console.log(avar);
//   }
// });

// const readline = require("readline-sync");

// const number = readline.question("enter number:");

// console.log(isNaN(number));

const ex = "jk2,d3kj,d3kj,d23d";
console.log(ex.split(","));
