const routes = require("express").Router();
routes.get("/dynamicGrid", (req, res) => {
  res.render("pages/JSproject/JS1_dynamic_grid");
});

routes.get("/functionGrid", (req, res) => {
  res.render("pages/JSproject/JS2_functions_grid");
});
routes.get("/kukuCube", (req, res) => {
  res.render("pages/JSproject/JS3_kuku_cube");
});

routes.get("/ticTacToe", (req, res) => {
  res.render("pages/JSproject/JS4_tic_tac_toe");
});

module.exports = routes;
