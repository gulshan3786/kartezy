const routes = require("express").Router();

routes.get("/ehya", (req, res) => {
  res.render("pages/CSSproject/CSS1_ehya.ejs");
});

routes.get("/AwanHoster", (req, res) => {
  res.render("pages/CSSproject/CSS2_Awan_Hoster.ejs");
});
routes.get("/HireX", (req, res) => {
  res.render("pages/CSSproject/CSS3_HireX.ejs");
});

module.exports = routes;
