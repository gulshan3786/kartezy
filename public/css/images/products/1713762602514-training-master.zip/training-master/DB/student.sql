use students;

create table student_master(
	std_id int auto_increment,
    std_name varchar(20) not null,
    primary key (std_id)
);
select * from student_master;


create table subject_master(
	sub_id int auto_increment,
    sub_name varchar(20),
    primary key(sub_no)
);

alter table subject_master auto_increment=101;
select * from subject_master;

create table attendence(
	att_id int auto_increment primary key,
	att_student int,
    att_date date,
    att_status boolean,
    foreign key (att_student) references student_master(std_id)
);
alter table attendence auto_increment = 101;
select * from attendence;

create table exam(
	exam_id int auto_increment primary key,
    exam_type varchar(10),
    exam_std int,
    exam_sub int,
    exam_date date,
    exam_att boolean,
    theory_tm int,
    theory_om int,
    prac_tm int,
    prac_om int,
    foreign key (exam_std) references student_master(std_id),
    foreign key (exam_sub) references subject_master(sub_id)
);

alter table exam auto_increment=10001;
select * from exam;
alter table exam rename column prac_mm to prac_om;





