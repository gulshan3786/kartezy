create database student_27_2;
use student_27_2;
create table std_master(
	std_id int ,
    std_fname varchar(20) not null,
    std_lname varchar(20) not null,
    gender varchar(10),
    email varchar(100),
    dob date,
    city varchar(100),
    country varchar(100),
    sem int,
    entry_time timestamp(3) not null default current_timestamp(3),
    primary key (std_id)
);
LOAD DATA local INFILE '/home/abhishek-verma/Desktop/student_27_2.csv' 
INTO TABLE std_master 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
(std_id,std_fname,std_lname,gender,email,dob,city,country,sem);

select * from std_master;



create table attendence(
	att_id int auto_increment primary key,
	std_id int ,
    att_date date,
	attendence boolean,
    foreign key (std_id) references std_master(std_id)
);

select * from attendence;

SELECT distinct attendence.std_id,std_fname,std_lname  FROM std_master
INNER JOIN attendence ON std_master.std_id = attendence.std_id;

SELECT  attendence.std_id,count(att_date)  FROM attendence where attendence=1 and att_date between "2023-12-01" and "2023-12-31"  group by attendence.std_id;

SELECT  std_master.std_id,std_fname,std_lname,count(att_date)  FROM attendence inner join std_master on std_master.std_id=attendence.std_id where attendence=1 and att_date between "2023-12-01" and "2023-12-31"  group by attendence.std_id limit 20,10;


select std_master.std_id,std_fname,std_lname,
sum(case when exam_master.type_id = 1 then exam_master.p_omarks else 0 end) as pre_pr,
sum(case when exam_master.type_id = 1 then exam_master.t_omarks else 0 end) as pre_th,
sum(case when exam_master.type_id = 2 then exam_master.p_omarks else 0 end) as ter_pr,
sum(case when exam_master.type_id = 2 then exam_master.t_omarks else 0 end) as ter_th,
sum(case when exam_master.type_id = 3 then exam_master.p_omarks else 0 end) as fin_pr,
sum(case when exam_master.type_id = 3 then exam_master.t_omarks else 0 end) as fin_th 
from std_master inner join exam_master on std_master.std_id=exam_master.std_id 
group by std_id;

select exam_master.sub_id,sub_name,
sum(case when exam_master.type_id = 1 then exam_master.p_omarks else 0 end) as pre_pr,
sum(case when exam_master.type_id = 1 then exam_master.t_omarks else 0 end) as pre_th,
sum(case when exam_master.type_id = 2 then exam_master.p_omarks else 0 end) as ter_pr,
sum(case when exam_master.type_id = 2 then exam_master.t_omarks else 0 end) as ter_th,
sum(case when exam_master.type_id = 3 then exam_master.p_omarks else 0 end) as fin_pr,
sum(case when exam_master.type_id = 3 then exam_master.t_omarks else 0 end) as fin_th 
from (exam_master inner join subject on exam_master.sub_id=subject.sub_id) inner join std_master on std_master.std_id=exam_master.std_id 
where exam_master.std_id =1
group by sub_id;

select exam_master.sub_id,sub_name,
(case when exam_master.type_id = 1 then exam_master.p_omarks else 0 end) as pre_pr,
(case when exam_master.type_id = 1 then exam_master.t_omarks else 0 end) as pre_th,
(case when exam_master.type_id = 2 then exam_master.p_omarks else 0 end) as ter_pr,
(case when exam_master.type_id = 2 then exam_master.t_omarks else 0 end) as ter_th,
(case when exam_master.type_id = 3 then exam_master.p_omarks else 0 end) as fin_pr,
(case when exam_master.type_id = 3 then exam_master.t_omarks else 0 end) as fin_th 
from (exam_master inner join subject on exam_master.sub_id=subject.sub_id) inner join std_master on std_master.std_id=exam_master.std_id 
where exam_master.std_id =1;

show tables;

select * from std_master;
select * from std_master where std_id in (1) limit 0,2;
select * from std_master where std_id in (90) limit 0,2;
select * from std_master where city in ('bissau' and 'tampa' and 'fairbanks');

select * from std_master where std_fname like '%abhi%' or std_fname like '%pal%' && std_lname like '%verma%' && gender like '%male%' && dob like '%2002%' && city like '%gandhinagar%' && country like '%india%' && sem like '8%' ;

