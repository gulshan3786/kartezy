show databases;



use students;
create table std_usingcmdln(
	roll_no int,
    first_name varchar(12),
    last_name varchar(12),
    email varchar(20),
    address varchar(30),
    dob date,
    father_name varchar(30),
    mother_name varchar(30),
    gender varchar(6),
    marks int,
    contact int
);
create table std_constraints1(
	roll_no int,
    first_name varchar(12),
    last_name varchar(12),
    email varchar(20),
    address varchar(30),
    dob date,
    father_name varchar(30),
    mother_name varchar(30),
    gender varchar(6),
    marks int,
    contact int(10),
    constraint pk_students primary key (roll_no,contacts,email)  
);
select * from std_constraint1;

create table std_constraints2(
	roll_no int primary key,
    first_name varchar(12) not null unique,
    last_name varchar(12) not null unique,
    email varchar(20) unique,
    address varchar(30),
    dob date not null,
    father_name varchar(30),
    mother_name varchar(30),
    gender varchar(6),
    marks int,
    contact int(10) unique
);
select * from std_constraint2;
 
create table std_constraints3(
	roll_no int primary key,
    first_name varchar(12),
    last_name varchar(12),
    email varchar(20),
    address varchar(30),
    dob date not null,
    father_name varchar(30),
    mother_name varchar(30),
    gender varchar(6),
    marks int,
    contact int(10)
);
select * from std_constraints3;
alter table std_constraints3
drop primary key;
alter table std_constraints3
add constraint pk_students primary key(contact,email);

create table std_autoincrement(
	roll_no int not null auto_increment,
    first_name varchar(12),
    last_name varchar(12),
    email varchar(20),
    address varchar(30),
    dob date not null,
    father_name varchar(30),
    mother_name varchar(30),
    gender varchar(6),
    marks int,
    contact bigint,
    primary key (roll_no)
);
select * from std_autoincrement;
alter table std_autoincrement auto_increment = 100;

create table std_datatypes(
	roll_no  tinyint,
    first_name varchar(12),
    last_name varchar(12),
    email varchar(20),
    address char(30),
    dob date,
    gender varchar(6),
    cgpa float(4,2),
    contact bigint
);
select * from std_datatypes;

create table std_fkey1(
	roll_no  tinyint,
    first_name varchar(12),
    last_name varchar(12),
    father_name varchar(13),
    primary key (roll_no),
    foreign key (father_name) references std_fkey2(father_name)
);
create table std_fkey2(
    father_name varchar(13),
    profesion varchar(12),
    salary int,
    primary key (father_name)
);

create table std_check(
	roll_no int not null auto_increment,
    first_name varchar(12),
    last_name varchar(12),
    obtained_marks tinyint(2) check(100>obtained_marks>=0),
    passing_marks tinyint(2) not null check(passing_marks>=37),
    constraint passed check(obtained_marks>=passing_marks),
    primary key (roll_no)
);

