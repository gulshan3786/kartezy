create database job_ap_db_29;
use job_ap_db_29;

create table employee(
	id int auto_increment primary key,
	first_name varchar(20) not null,
    last_name varchar(20) not null,
    emp_designation varchar(20),
    gender varchar(12),
    address1 varchar(30),
    address2 varchar(30),
    relationship_status varchar(12),
    city varchar(20),
    phone bigint unique key not null,
    zip_code int,
    dob date
);

create table work_exp(
	work_id int auto_increment primary key,
    employee_id int,
    company_name varchar(20),
	work_designation varchar(20),
    work_from date,
    work_to date,
    foreign key (employee_id) references employee(employee_id)
);

create table tech_known(
	tech_id int auto_increment primary key,
    employee_id int,
    tech_name varchar(20),
    tech_eff varchar(12)
);


create table language_known(
	language_id int auto_increment primary key,
    employee_id int,
    language_name varchar(12),
    lang_read boolean,
    lang_speak boolean,
    lang_write boolean,
    foreign key (employee_id) references employee(employee_id)
);


create table reference_contact(
	ref_id int auto_increment primary key,
    employee_id int,
    ref_name varchar(20),
    ref_contact int,
    ref_relation varchar(20),
    foreign key (employee_id) references employee(employee_id)
);

create table preferences(
	preference_id int auto_increment primary key,
    employee_id int,
    loacation varchar(20),
    notice_period int,
    expected_ctc int,
    current_ctc int,
    department varchar(20),
    foreign key (employee_id) references employee(employee_id)
);
create table education(
	education_id int auto_increment primary key,
    education_type varchar(10),
    board_name varchar(20),
    passing_year int,
    passing_percentage int
);

create table select_master(
	select_id int auto_increment primary key,
    select_key varchar(20) unique key not null 
);
select * from select_master order by select_id;

create table options_master(
	option_id int auto_increment primary key,
    select_id int,
    select_key varchar(20),
    option_name varchar(20),
    foreign key (select_id) references select_master(select_id)
);
select * from options_master order by select_id;

insert into select_master (select_key) values
('gender_key'), 
('relationship_key'),
('education_key'),
('lang_key'),
('tech_eff'),
('location_key'),
('department_key');


insert into options_master (select_id,select_key,option_name) values 
(1,'gender_key','male'),
(1,'gender_key','female'),
(2,'relation_key','single'),
(2,'relation_key','married'),
(2,'relation_key','divorced'),
(3,'education_key','ssc'),
(3,'education_key','hsc'),
(3,'education_key','bachelor'),
(3,'education_key','master'),
(4,'lang_key','hindi'),
(4,'lang_key','english'),
(4,'lang_key','gujarati'),
(5,'tech_eff','beginner'),
(5,'tech_eff','mideator'),
(5,'tech_eff','expert'),
(6,'location_key','ahmedabad'),
(6,'location_key','gandhinagar'),
(7,'department_key','development'),
(7,'department_key','hr'),
(7,'department_key','business analyst');



