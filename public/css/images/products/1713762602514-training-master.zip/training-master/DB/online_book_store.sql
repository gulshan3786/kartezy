create database online_book_store;
use online_book_store;


create table author(
	author_id int primary key,
    author_name varchar(30) not null,
    author_login varchar(50) not null,
    author_password varchar(12) not null
);

create table publisher(
	pub_id int primary key,
    pub_name varchar(30) not null,
	pub_login varchar(50) not null,
    pub_password varchar(12) not null
);

create table customer(
	cus_id int primary key,
    cus_name varchar(30) not null,
    cus_login varchar(50) not null,
    cus_password varchar(12) not null,
    cus_address varchar(50) not null,
    phone bigint not null,
    cus_account bigint not null
);

create table book(
	book_id int not null primary key,
    book_name varchar(30) not null,
    author_id int,
    pub_id int,
    price int,
    quantity int,
    foreign key (author_id) references author(author_id),
    foreign key (pub_id) references publisher(pub_id)
);

create table payment(
	payment_id int primary key,
    cus_id int,
    payment_time  timestamp not null default current_timestamp,
    amount int,
    foreign key (cus_id) references customer(cus_id)
);

create table orders(
	order_id int primary key,
    book_id int,
    cus_id int,
    pub_id int,
    author_id int,
    order_date timestamp not null default current_timestamp,
    order_quantity int not null,
    payment_id int,
    foreign key (author_id) references author(author_id),
    foreign key (pub_id) references publisher(pub_id),
    foreign key (book_id) references book(book_id),
    foreign key (payment_id) references payment(payment_id)
);



