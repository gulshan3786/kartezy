use students;

-- get attendence

select * from student_master inner join attendence
on attendence.att_student=student_master.std_id ;

select * from student_master cross join attendence
on attendence.att_student=student_master.std_id ;

select * from student_master left join attendence
on attendence.att_student=student_master.std_id ;

select * from attendence cross join student_master
on attendence.att_student=student_master.std_id ;

select * from attendence left join student_master
on attendence.att_student=student_master.std_id ;

select * from attendence right join student_master
on attendence.att_student=student_master.std_id ;

select * from student_master cross join attendence
on attendence.att_student=student_master.std_id ;

select student_master.std_id,student_master.std_name,attendence.att_id,att_date,att_status
from student_master inner join attendence 
on att_student=std_id;

select std_id,std_name,att_id,att_date,att_status
from student_master inner join attendence 
on att_student=std_id;

select std_name,count(att_status) as presentDays 
from attendence inner join student_master  
on att_student = std_id where att_status=1 
group by std_name ;

-- exam marks

select * from student_master inner join exam 
on exam_std = std_id where exam_type='prelims';
 
select * from student_master inner join exam 
on exam_std = std_id where exam_type='prelims' and exam_sub='101';
select * from student_master inner join exam 
on exam_std = std_id where exam_type='prelims' and exam_sub='102';
select * from student_master inner join exam 
on exam_std = std_id where exam_type='prelims' and exam_sub='103';
select * from student_master inner join exam 
on exam_std = std_id where exam_type='prelims' and exam_sub='104';
select * from student_master inner join exam 
on exam_std = std_id where exam_type='prelims' and exam_sub='105';
select * from student_master inner join exam 
on exam_std = std_id where exam_type='prelims' and exam_sub='106';

select * from subject_master right join exam 
on exam_sub=sub_id where (theory_om >= 33 and prac_om >= 12) and not(exam_type='prelims' or exam_type='terminals'); 

