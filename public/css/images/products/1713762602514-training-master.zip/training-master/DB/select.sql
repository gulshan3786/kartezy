select * from student_master;
select * from subject_master;
select * from attendence;
select * from exam;

select distinct std_name from student_master;
select distinct sub_name from subject_master;
select distinct exam_date from exam;
select distinct att_date from attendence; 

select std_id from student_master;
select sub_id from subject_master;
select att_id from attendence;
select exam_id from exam;

select theory_om from exam having (theory_om)>=20;
select exam_att from exam where exam_att=0;
select exam_id from exam where theory_om>=33 or exam_type='finals';
select exam_id from exam where theory_om>=30 and prac_om>=10 or exam_type='prelims';
select att_id from attendence where not att_status=1;

select * from exam where exam_type ='prelims' order by theory_om;
select * from exam order by prac_om desc ;
select * from exam where exam_type = 'terminals' order by theory_om asc,prac_om desc;


-- string fun

select std_name, ascii(std_name) as asciiofstdfrstchar from student_master;
select ascii(sub_name) as asciiofsubfrstchar from subject_master;
select char_length(std_name) as lengthOfName from student_master;
select character_length(sub_name) as lengthOfName from subject_master;
select concat(sub_id," ",sub_name) as subjectInfortmation from subject_master;
select concat_ws(".",std_id,std_name) as studentInfo from student_master;
select field("verma","abhishek","verma");
select find_in_set("crane","eagle,falcon,crane");
select find_in_set('john',std_name) from student_master;
select insert ('mary',3,4,'jane');
select instr(std_name,"abhishek") as position from student_master;
select ucase(std_name) from student_master;
select lcase(std_name) from student_master;
select left(std_name,4) from student_master;
select right(std_name,3) from student_master;
select length(std_name) as stringlength from student_master;
select locate('dbms',std_name) from student_master;
select lpad(sub_name,4,'0') from subject_master;
select ltrim("    abhi");
select repeat("hello ",3);
select replace("good morning,good evening",'good','bad');
select space(5);
select strcmp('many','right');
select trim("    noway    ");

-- numeric fun
select abs(sub_id) as absoluteValue from subject_master;
select acos(std_id) from student_master;
select asin(std_id) from student_master;
select atan(sub_id) from subject_master;
select atan2(prac_om,theory_om) from exam;
select avg(theory_om) as avgOftheory from exam;
select ceil(sub_id) from subject_master;
select ceil(98.6);
select cos(90);
select sin(90);
select count(distinct exam_date) from exam;
select degrees(33.32);
-- select theory_om div 2 as halfmarks from exam where exam_type='finals'  ;
select exp(std_id) from student_master;
select floor(56.37);
select greatest(4,2,312,1,31,2);
select least(62,31,31,23,21,32,2134,3,12,2);
select ln(2);
select max(theory_om) from exam;
select min(prac_om) from exam;
select mod(theory_om,prac_om) from exam;
select sign(-1);
select round(28715.63248,3);
select sum(att_status) from attendence;

-- date functions

select adddate('2024-06-08',interval 20 day); 
select adddate(att_date,interval 10 day) from attendence;
select curdate();
select curtime();
select current_timestamp();
select datediff('2024-06-01','2024-07-30');
select date_format(att_id,'%a') from attendence; -- day
select date_format(att_id,'%b') from attendence; -- month
select date_format(att_id,'%c') from attendence;
select date_format(att_id,'%d') from attendence; -- day numeric value
select date_format(att_id,'%D') from attendence; -- numeric 1st
select date_format(att_id,'%e') from attendence;
select date_format(att_id,'%f') from attendence; -- microsec
select date_format(att_id,'%H') from attendence; -- hour 0 to 23
select date_format(att_id,'%h') from attendence; -- 0 to 12
select date_format(att_id,'%i') from attendence;
select date_format(att_id,'%I') from attendence;
select date_format(att_id,'%j') from attendence;
select date_format(att_id,'%k') from attendence;
select date_format(att_id,'%l') from attendence;
select date_format(att_id,'%M') from attendence;
select date_format(att_id,'%m') from attendence;
select date_format(att_id,'%p') from attendence; -- pm am
select date_format(att_id,'%r') from attendence;
select date_format(att_id,'%S') from attendence;
select date_format(att_id,'%s') from attendence;
select date_format(att_id,'%T') from attendence;
select date_format(att_id,'%U') from attendence;
select date_format(att_id,'%u') from attendence;
select date_format(att_id,'%V') from attendence;
select date_format(att_id,'%v') from attendence;
select date_format(att_id,'%w') from attendence;
select date_format(att_id,'%W') from attendence;
select date_format(att_id,'%X') from attendence;
select date_format(att_id,'%x') from attendence;
select date_format(att_id,'%y') from attendence;
select date_format(att_id,'%Y') from attendence;
select date_sub('2025-01-10',interval 10 day);
select day(exam_date) from exam;
select dayname(exam_date) from exam;
select dayofmonth(att_id) from attendence;
select extract(week from exam_date) from exam;

select rand(2);
select rand();
