create database student_db_1;
use student_db_1;
show global variables like 'local_infile';
set global local_infile=true;
show full processlist;

create table std_master(
	std_id int ,
    std_fname varchar(20) not null,
    std_lname varchar(20) not null,
    gender varchar(10),
    email varchar(100),
    dob date,
    city varchar(100),
    country varchar(100),
    sem int,
    entry_time timestamp(3) not null default current_timestamp(3),
    primary key (std_id)
);


LOAD DATA local INFILE '/home/abhishek-verma/Desktop/student.csv' 
INTO TABLE std_master 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
(std_id,std_fname,std_lname,gender,email,dob,city,country,sem);



create table exam_master(
	exam_id int,
    e_type varchar(10),
    std_id int,
    sub_id int,
    p_omarks int,
    p_tmarks int,
    t_omarks int,
    t_tmarks int,
    total_omarks int,
    total_marks int,
    e_date date,
    entry_time timestamp(3) not null default current_timestamp(3),
	primary key (exam_id)
);



LOAD DATA LOCAL INFILE '/home/abhishek-verma/Desktop/exam.csv' 
INTO TABLE std_master
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
(exam_id,e_type,std_id,sub_id,p_omarks,p_tmarks,t_omarks,t_tmarks,total_omarks,total_marks,e_date);


select * from std_master;
 
select * from exam_master;

select * from exam_master
order by p_omarks;

select * from exam_master
order by p_omarks desc;

select * from std_master cross join exam_master;

select * from std_master inner join exam_master on std_master.std_id = exam_master.std_id;
select * from std_master left join exam_master on std_master.std_id = exam_master.std_id;
select * from std_master right join exam_master on std_master.std_id = exam_master.std_id;

select * from exam_master order by p_omarks asc,t_omarks desc;

select * from std_master left join exam_master on std_master.std_id = exam_master.std_id order by  exam_id asc,std_master.std_id desc,t_omarks asc,p_omarks desc;
select * from std_master right join exam_master on std_master.std_id = exam_master.std_id order by  exam_id asc,std_master.std_id desc,t_omarks asc,p_omarks desc;

select * from std_master left join exam_master on std_master.std_id = exam_master.std_id order by std_fname asc,std_lname desc,gender asc,email desc,city asc, country desc;
select * from std_master right join exam_master on std_master.std_id = exam_master.std_id order by std_fname asc,std_lname desc,gender asc,email desc,city asc, country desc;

select * from std_master left join exam_master on std_master.std_id = exam_master.std_id order by exam_id asc,std_master.std_id desc,t_omarks asc,p_omarks desc,std_fname asc,std_lname desc,gender asc,email desc,city asc, country desc;
select * from std_master right join exam_master on std_master.std_id = exam_master.std_id order by exam_id asc,std_master.std_id desc,t_omarks asc,p_omarks desc,std_fname asc,std_lname desc,gender asc,email desc,city asc, country desc;

select * from std_master left join exam_master on std_master.std_id = exam_master.std_id order by std_master.entry_time,exam_master.entry_time,dob;
select * from std_master right join exam_master on std_master.std_id = exam_master.std_id order by std_master.entry_time,exam_master.entry_time,dob;

select std_fname,std_lname from std_master;
select entry_time from std_master;

select p_omarks,t_omarks from exam_master;
select e_date,entry_time from exam_master;

select city from std_master left join exam_master on std_master.std_id = exam_master.std_id order by  std_fname asc,std_lname desc,std_master.entry_time asc,p_omarks desc,t_omarks asc, e_date desc,exam_master.entry_time asc;


select sub_id,count(std_id) from  exam_master where omarks>50 group by sub_id ;

select std_master.std_fname from std_master cross join exam_master where omarks>30;

select std_fname from std_master cross join exam_master where sub_id=1 and omarks = 63;

 select std_fname from std_master cross join exam_master on std_master.std_id=exam_master.std_id;

select * from std_master cross join exam_master on std_master.std_id=exam_master.std_id;






 

