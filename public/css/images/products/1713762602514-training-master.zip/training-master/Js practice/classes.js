class rectangle{
    constructor(height,width){
        this.height = height;
        this.width = width;
    }
}