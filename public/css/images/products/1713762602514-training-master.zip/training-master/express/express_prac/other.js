exports.add = function (req, res, next) {
  console.log(3 + 4);
};
